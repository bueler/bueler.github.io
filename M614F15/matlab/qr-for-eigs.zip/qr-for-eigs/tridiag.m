function T = tridiag(A);
% TRIDIAG  Implement Algorithm 26.1 ("Householder Reduction to Hessenberg
% Form") to reduce a hermitian matrix to tridiagonal form and sparse storage.
% This is Exercise 29.1 (a).
% Example:
%   >> A = hilb(4),  T=tridiag(A),  full(T)

m = size(A,1);
if (m ~= size(A,2)) | (norm(A'-A,1) > 10*eps*norm(A,1))
    error('only applies to square Hermitian matrices')
end
for k = 1:m-2
    v = A(k+1:m,k);
    if v(1) >= 0.0
        v(1) = norm(v) + v(1);
    else
        v(1) = - norm(v) + v(1);
    end
    v = v / norm(v);
    A(k+1:m,k:m) = A(k+1:m,k:m) - 2 * v * (v' * A(k+1:m,k:m));
    A(1:m,k+1:m) = A(1:m,k+1:m) - 2 * (A(1:m,k+1:m) * v) * v';
end
% force sparse, tridiagonal, and Hermitian
v = diag(A,-1);       % subdiagonal
T = spdiags([[v; 0] diag(A) [0; v]],[-1 0 1],m,m);

