function [lambda, offlist] = eigherm(A,doshift)
% EIGHERM  Apply QR algorithm for eigenvalues to a Hermitian matrix.
% Calls QRALG for QR steps and then deflates.  Optionally returns
% list with values |t_{m,m-1}|.
% Usage:
%    [lambda, offlist] = eigherm(A,doshift)
% Example Exercise 29.1(c) in Tref & Bau:
%    >> A = hilb(4)
%    >> lam = eigherm(A,false)
%    >> norm(sort(eig(A)) - sort(lam))
%    >> [lam, ol] = eigherm(A,false);  showofflist(A,ol)
% Exercise 29.1(d):
%    >> [lam, ol] = eigherm(A,true);  showofflist(A,ol)
% Exercise 29.1(e):
%    >> A = diag(15:-1:1) + ones(15,15);  
%    >> [lam, ol] = eigherm(A,false);  showofflist(A,ol)
%    >> [lam, ol] = eigherm(A,true);  showofflist(A,ol)

if nargin < 2,  doshift = true;  end
m = size(A,1);
if (m ~= size(A,2)), error('A must be square'); end
if (norm(A'-A,1) > 10*eps*norm(A,1)), error('A must be Hermitian'); end

Tnew = tridiag(A);
offlist = [];
lambda = zeros(m,1);
for j = m:-1:2
    [T,ol] = qralg(Tnew,doshift,1.0e-12);
    offlist = [offlist ol];
    lambda(j) = T(j,j);
    Tnew = T(1:j-1,1:j-1);
end
lambda(1) = T(1,1);

