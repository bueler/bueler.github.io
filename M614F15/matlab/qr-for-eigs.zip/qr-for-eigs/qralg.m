function [Tnew,offlist] = qralg(T,doshift,tol)
% QRALG  Apply naive (=unshifted) QR algorithm (Alg. 28.1 "Pure QR")
% or Wilkinson-shifted (Alg. 28.2) to a Hermitian tridiagonal matrix.
% Optimized to use 2x2 Householder reflections.  Compare HOUSE.
% This is Exercise 29.1(b) in Tref&Bau.
% Example:
%    >> A = hilb(4);  T = tridiag(A);  full(qralg(T))
%    >> norm(sort(eig(A)) - sort(eig(qralg(T))))

if nargin < 3,  tol = 1.0e-12;  end % as in Tref&Bau Exer 29.1 (b)
if nargin < 2,  doshift = true;  end

m = size(T,1);
if (m ~= size(T,2)), error('T must be square'); end
if (norm(T'-T,1) > 10*eps*norm(T,1)), error('T must be Hermitian'); end
if (norm(triu(T,2)+tril(T,-2),1) > 10*eps*norm(T,1)), error('T must be tridiagonal'); end

if m == 1,  Tnew = T;  offlist = [];  return;  end

W = zeros(2,m-1);     % space to store v vectors for 2x2 Householder reflects

offlist(1) = [abs(full(T(m,m-1)))];
mu = 0.0;
while offlist(end) >= tol    
    if doshift        % see "Wilkinson shift" on page 222
        delta = (T(m-1,m-1) - T(m,m)) / 2;
        bmm = T(m-1,m);
        mu = T(m,m) - sign(delta) * bmm^2 / (abs(delta) + sqrt(delta^2 + bmm^2));
        for j = 1:m
            T(j,j) = T(j,j) - mu;
        end
    end
    for k = 1:m-1     % do  T ---> Q' T = R
        v = T(k:k+1,k);
        v(1) = sign(v(1)) * norm(v) + v(1);
        v = v / norm(v);
        T(k:k+1,k:m) = T(k:k+1,k:m) - 2 * v * (v' * T(k:k+1,k:m));
        W(:,k) = v;
    end               % do  R ---> R Q = Q' T Q
    T(m,m) = -1 * T(m,m);      % in HOUSE, Q_m on left is sign change last row
    for k = 1:m-1
        v = W(:,k);
        T(1:m,k:k+1) = T(1:m,k:k+1) - 2 * (T(1:m,k:k+1) * v) * v';
    end
    T(1:m,m) = -1 * T(1:m,m);  % in HOUSE, Q_m on right is sign change last col
    offlist = [offlist abs(full(T(m,m-1)))];
    if doshift
        for j = 1:m
            T(j,j) = T(j,j) + mu;
        end
    end
end
% force sparse, tridiagonal, and Hermitian
v = diag(T,-1);       % subdiagonal
Tnew = spdiags([[v; 0] diag(T) [0; v]],[-1 0 1],m,m);

