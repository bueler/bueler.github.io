function showofflist(A, ol)
% SHOWOFFLIST  Produce semilogy() plot of off-diagonal magnitudes from
% running EIGHERM.

scale = norm(A,1);
semilogy(ol,'o-')
xlabel('QR iterations')
ylabel('off-diagonal magnitude')
axis([1 length(ol) 1.0e-18*scale scale])
grid on
